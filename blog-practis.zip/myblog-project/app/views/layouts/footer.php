<footer class="main-footer">
    <div class="container">
        <div style="display: flex; flex-wrap: wrap; justify-content: space-between; gap: 2rem;">
            <div>
                <p><strong>درباره ما:</strong><br>وبلاگ آموزشی من.</p>
            </div>
            <div>
                <p><strong>تماس با ما:</strong><br>ایمیل: info@example.com</p>
            </div>

        </div>
        <hr style="margin: 2rem 0; border-color: #ccc;">
        <p style="text-align: center;">© تمامی حقوق محفوظ است - <?= date('Y') ?></p>
    </div>
</footer>

</body>
</html>
