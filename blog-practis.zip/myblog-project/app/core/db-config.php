<?php

return [
    'host' => 'localhost',
    'name' => 'myblog',
    'user' => 'root',
    'pass' => ''
];
