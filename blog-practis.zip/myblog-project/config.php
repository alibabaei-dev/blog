<?php

define('BASE_URL', '/myblog-project/public/');

